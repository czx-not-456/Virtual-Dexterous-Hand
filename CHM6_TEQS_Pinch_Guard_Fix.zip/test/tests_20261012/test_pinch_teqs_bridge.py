"""Regression tests for PINCH/object-goal TEQS guard integration (no mujoco dependency)."""
from pathlib import Path
import numpy as np
import yaml

from src.hand_model.robot_hand import RobotHandModel
from src.retargeting.latent_synergy import LatentSynergyMapper
from src.retargeting.task_effect_spectrum import TaskEffectSpectrumMapper
from src.retargeting.task_space_servo import ObjectAwareTaskServo
from src.features.intent_recognition import Intent

ROOT = Path(__file__).resolve().parents[2]


def make_mapper():
    model = LatentSynergyMapper(RobotHandModel(), ROOT/'configs/latent_chm6_adaptive.json')
    return TaskEffectSpectrumMapper(model, yaml.safe_load((ROOT/'configs/task_effect_spectrum.yaml').read_text()))


def test_object_goal_can_accept_useful_deviation_beyond_1p5_degree_limit():
    m = make_mapper()
    uref = np.full(6, 0.35)
    prev = m.decode_controls(uref)
    m.set_command_anchor(prev, np.full(11, np.deg2rad(360)), 1/60)
    tips = m.robot.fingertips(prev)
    m.optimize(lambda q: float(q @ q), prev, Intent.PINCH, uref,
               task_targets_m={f:tips[f] for f in m.FINGERS[Intent.PINCH]})
    u_goal = uref.copy()
    u_goal[1] += 0.03
    def predictor(q, finger_names):
        u = m.encode_joints(q)
        result = {'thumb': np.array([u[1]*.10, 0.,0.]),
                  'index': np.array([u[2]*.10,0.,0.])}
        return {k:result[k] for k in finger_names}
    goal = {'thumb': np.array([u_goal[1]*.10,0.,0.]),
            'index': np.array([uref[2]*.10,0.,0.])}
    m.set_object_task_goal(predictor, goal)
    out = m.project_and_rate_limit(m.decode_controls(u_goal), prev,
                                   np.full(11,np.deg2rad(360)), 1/60)
    assert m.last_diag.final_guard_used is False
    assert m.last_diag.final_guard_reason == 0
    assert m.encode_joints(out)[1] > uref[1] + 0.015
    assert m.last_diag.final_object_task_error_m < m.last_diag.final_object_baseline_m
    assert m.last_diag.rate_box_valid
    assert np.allclose(out, m.decode_controls(m.encode_joints(out)), atol=1e-8)


def test_object_goal_rejects_worse_contact_candidate():
    m = make_mapper()
    ref = np.full(6, 0.35)
    prev = m.decode_controls(ref)
    m.set_command_anchor(prev, np.full(11,np.deg2rad(360)), 1/60)
    tips=m.robot.fingertips(prev)
    m.optimize(lambda q:float(q@q),prev,Intent.PINCH,ref,
            task_targets_m={f:tips[f] for f in m.FINGERS[Intent.PINCH]})
    def predictor(q, fingers):
        u=m.encode_joints(q)
        out={'thumb': np.array([u[1]*.10,0.,0.]),
             'index': np.array([u[2]*.10,0.,0.])}
        return {f:out[f] for f in fingers}
    m.set_object_task_goal(predictor,{'thumb': np.array([ref[1]*.10,0.,0.])})
    bad=ref.copy(); bad[1]+=.05
    out=m.project_and_rate_limit(m.decode_controls(bad),prev,
                                  np.full(11,np.deg2rad(360)),1/60)
    assert m.last_diag.final_guard_used
    assert m.last_diag.final_guard_reason==1
    assert np.allclose(out,prev,atol=1e-7)


class _LinearThumbSim:
    def __init__(self, robot, mapper):
        self.robot=robot
        self.mapper=mapper
        self.actual=mapper.decode_controls(np.full(6,.35))
    def joint_positions(self): return self.actual.copy()
    def fingertip_position(self,finger): return np.zeros(3)
    def task_contact_target(self,finger,task_name,clearance_m,vertical_margin_m):
        return np.array([.015,0,0]) if finger=='thumb' else np.array([.005,0,0])
    def fingertip_jacobian(self,finger,joint_names):
        J=np.zeros((3,len(joint_names)))
        J[0,0]=.1
        return J


def test_servo_outputs_exact_six_control_coupling():
    m=make_mapper()
    robot=RobotHandModel()
    srv=ObjectAwareTaskServo(robot,{'enabled':True,'gain':.8,'damping':.02,
        'max_joint_step_deg':6.0,'pinch':{'active_intent':'PINCH','command_blend':.92}})
    sim=_LinearThumbSim(robot,m)
    q=m.decode_controls(np.full(6,.35))
    cmd,diag=srv.apply_coupled(q,simulator=sim,task_name='pinch',task_mode='pinch',
                                  intent_value='PINCH',contact={},mapper=m)
    assert diag.active and diag.corrected_digits==2
    assert np.allclose(cmd,m.decode_controls(m.encode_joints(cmd)),atol=1e-9)
    assert np.all(m.encode_joints(cmd)>=m.lower-1e-9)
    assert np.all(m.encode_joints(cmd)<=m.upper+1e-9)
    assert np.linalg.norm(cmd-q)>0
